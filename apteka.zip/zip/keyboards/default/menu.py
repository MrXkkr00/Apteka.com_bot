from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

bosh_menu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="🔍 Поиск лекарств"),
        ],
        [
            KeyboardButton(text="Как пользоваться❓"),
        ],
        [
            KeyboardButton(text="📝 Оставить отзыв"),
            KeyboardButton(text="Информация 📖")
        ],
    ],resize_keyboard=True
)

information = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="ℹ️ О нас"),
        ],
        [
            KeyboardButton(text="📞 Контакты"),
        ],

        [
            KeyboardButton(text="🤖Программист телеграмм-ботов от 50$ до 200$"),
        ],
    ],resize_keyboard=True
)
